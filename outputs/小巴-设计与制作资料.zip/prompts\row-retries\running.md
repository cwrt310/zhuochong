Create ChatGPT pet row `running` for `xiaoba`: exactly 6 full-body frames in one horizontal strip on flat pure green #00FF00.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Use right white-haired character. Compact full-body chibi anime sticker, huge blue eyes, silver-white long hair to coat hem, two blue bows, white coat with blue trim, navy high-neck dress, blue-white sneakers. Small opaque blue geometric core ball held at belly with connected hands. Friendly curious focused. No letters or logos. Clean dark navy outline readable at 192x208. Body and shoes anchored for look directions, head pitches and yaws gently, pupils and nose follow gaze, face always readable, bows follow head. No detached effects or shadows, no external glow.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Working loop: focused active-task processing, thinking, typing, scanning, or effortful concentration; not literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, or directional travel.

State requirements:
- Show the pet actively working or processing, as if running a task: focused posture, busy hands or paws, purposeful bobbing, thinking motion, tool or prop motion only if already part of the pet identity, or other non-locomotion activity.
- Do not show literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, directional travel, speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #00FF00 colors in the pet.
